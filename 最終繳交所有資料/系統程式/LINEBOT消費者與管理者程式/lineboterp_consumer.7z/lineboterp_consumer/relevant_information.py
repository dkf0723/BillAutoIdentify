def linebotinfo():
    linebotdata = {
        'LineBotApidata':'2+5H1PGPxcuiHvmd4OJ6aa9w0//wo1Q1XhXX9dx/AT9I3e+u4nEUedXpclarLzV2k3kQ6uoqjfGUnZ+rqCGgt8yrcMUw58r9DREQslLPxWvb03oxdf2AseFYzpdCeWRykWIfjpbcBB2o8LrTzP2LTQdB04t89/1O/w1cDnyilFU=',
        'WebhookHandlerdata':'cc36511a908df2f50e98845cbd8216aa'
    }
    return linebotdata

def dbinfo():
    dbdata = {
        'host':'140.131.114.242',
        'user':'112405',
        'password':'!mdEe24@5',
        'database':'112-112405'
    }
    return dbdata

def imgurinfo():
    imgurdata = {
        'CLIENT_ID_data':'ebcfa98f6d190dc'
    }
    return imgurdata
